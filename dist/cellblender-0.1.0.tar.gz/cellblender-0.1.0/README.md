## 📦 PyPI
- For documentation refer to

https://alignment-tools.readthedocs.io/en/latest/cellblender.html

You can install this package via pip:

```bash
pip install cellblender
```

or first clone the package and then

```
pip install -e .


```
